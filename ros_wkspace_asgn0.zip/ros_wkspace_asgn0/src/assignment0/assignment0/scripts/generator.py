#!/usr/bin/env python
# license removed for brevity
import rospy
import random
from assignment0.msg import TwoInt

info = TwoInt()

def generator():
    pub = rospy.Publisher('/numbers', TwoInt, queue_size = 10)
    rospy.init_node('generator', anonymous=True)
    rate = rospy.Rate(10) # 10hz
    while not rospy.is_shutdown():
        info.num1 = random.randint(0,100) 
	info.num2 = random.randint(0,100)
        rospy.loginfo(info)
        pub.publish(info)
        rate.sleep()

if __name__ == '__main__':
    try:
        generator()
    except rospy.ROSInterruptException:
        pass
