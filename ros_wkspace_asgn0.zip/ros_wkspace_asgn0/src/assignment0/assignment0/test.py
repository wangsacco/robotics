#!/usr/bin/env python
# license removed for brevity
import rospy
import random
from assignment0.msg import TwoInt

bikk = TwoInt.num1
bikk = 5
print(bikk)
