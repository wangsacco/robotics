#!/usr/bin/env python

# Columbia Engineering
# MECS 4602 - Fall 2018

import math
import numpy
import time
from math import sqrt

import rospy

from state_estimator.msg import RobotPose
from state_estimator.msg import SensorData


class Estimator(object):
    def __init__(self):

        # Publisher to publish state estimate
        self.pub_est = rospy.Publisher("/robot_pose_estimate", RobotPose, queue_size=1)

        # Initial estimates for the state and the covariance matrix
        self.x = numpy.zeros((3, 1))
        self.P = numpy.zeros((3, 3))

        # Covariance matrix for process (model) noise
        self.V = numpy.zeros((3, 3))
        self.V[0, 0] = 0.0025
        self.V[1, 1] = 0.0025
        self.V[2, 2] = 0.005

        self.step_size = 0.01

        # Subscribe to command input and sensory output of robot
        rospy.Subscriber("/sensor_data", SensorData, self.sensor_callback)

    # This function gets called every time the robot publishes its control 
    # input and sensory output. You must make use of what you know about 
    # extended Kalman filters to come up with an estimate of the current
    # state of the robot and covariance matrix.
    # The SensorData message contains fields 'vel_trans' and 'vel_ang' for
    # the commanded translational and rotational velocity respectively. 
    # Furthermore, it contains a list 'readings' of the landmarks the
    # robot can currently observe
    def estimate(self, sens):
        #### ----- YOUR CODE GOES HERE ----- ####
        # F=df
        F = numpy.array([[1, 0, -self.step_size * sens.vel_trans * math.sin(self.x[2][0])],
                         [0, 1, self.step_size * sens.vel_trans * math.cos(self.x[2][0])]
                            , [0, 0, 1]])
        # xk+1=x+dx
        self.x[0][0] = self.x[0][0] + sens.vel_trans * math.cos(self.x[2][0]) * self.step_size
        self.x[1][0] = self.x[1][0] + sens.vel_trans * math.sin(self.x[2][0]) * self.step_size
        self.x[2][0] = self.x[2][0] + sens.vel_ang * self.step_size
        # prediced p
        xj = self.x
        pj = numpy.dot(numpy.dot(F, self.P), numpy.transpose(F)) + self.V
        yk1 = numpy.zeros((2,1))
        yp = numpy.zeros((2,1))
        Hxp = numpy.zeros((2,1))
        Hxk1 = numpy.zeros((2,1))
        H = numpy.zeros((2,3))
        Hp = numpy.zeros((2,3))
        dd = 0
        oo = 0
        if len(sens.readings) > 0:
            for i in range(len(sens.readings)):
                if (sqrt((sens.readings[i].landmark.x - self.x[0][0]) ** 2 + (
                        sens.readings[i].landmark.y - self.x[1][0]) ** 2)) < 0.1:
                    continue
                else:
                    oo = oo + 1
                    yp[0][0] = sens.readings[i].range
                    yp[1][0] = sens.readings[i].bearing
                    Hxp[0][0] = sqrt((sens.readings[i].landmark.x - self.x[0][0]) ** 2 + (
                            sens.readings[i].landmark.y - self.x[1][0]) ** 2)
                    Hxp[1][0] = math.atan2((sens.readings[i].landmark.y - self.x[1][0]),
                                           (sens.readings[i].landmark.x - self.x[0][0])) - self.x[2][0]
                    distance = (sens.readings[i].landmark.x - self.x[0][0]) ** 2 + (
                            sens.readings[i].landmark.y - self.x[1][0]) ** 2
                    Hp = numpy.array([[(self.x[0][0] - sens.readings[i].landmark.x) / sqrt(distance),
                                       (self.x[1][0] - sens.readings[i].landmark.y) / sqrt(distance), 0],
                                      [-(self.x[1][0] - sens.readings[i].landmark.y) / distance,
                                       (self.x[0][0] - sens.readings[i].landmark.x) / distance, -1]])
                    if (dd == 0):
                        dd = 1
                        yk1[0][0] = yp[0][0]
                        yk1[1][0] = yp[1][0]
                        Hxk1[0][0] = Hxp[0][0]
                        Hxk1[1][0] = Hxp[1][0]
                        for j in range(2):
                            for u in range(3):
                                H[j][u] = Hp[j][u]
                    else:
                        Hxk1 = numpy.vstack((Hxk1, Hxp))
                        H = numpy.vstack((H, Hp))
                        yk1 = numpy.vstack((yk1, yp))
            W = numpy.zeros((2 * oo, 2 * oo))
            for i in range(oo):
                W[2 * i][2 * i] = 0.1
                W[2 * i + 1][2 * i + 1] = 0.05
            if dd == 1:
                v = yk1-Hxk1
                for i in range(oo):
                    if v[2 * i + 1][0] > numpy.pi:
                        v[2 * i + 1][0] = v[2 * i + 1][0] - 2 * numpy.pi
                    if v[2 * i + 1][0] < -numpy.pi:
                        v[2 * i + 1][0] = v[2 * i + 1][0] + 2 * numpy.pi
                S = numpy.dot(H, numpy.dot(pj, numpy.transpose(H))) + W
                R = numpy.dot(pj, numpy.dot(numpy.transpose(H), numpy.linalg.inv(S)))
                self.x = self.x + numpy.dot(R, v)
                self.P = pj - numpy.dot(R, numpy.dot(H, pj))
            else:
                self.x = self.x
                self.P = pj
        else:
            self.x = self.x
            self.P = pj

        #### ----- YOUR CODE GOES HERE ----- ####

    def sensor_callback(self, sens):

        # Publish state estimate 
        self.estimate(sens)
        est_msg = RobotPose()
        est_msg.header.stamp = sens.header.stamp
        est_msg.pose.x = self.x[0]
        est_msg.pose.y = self.x[1]
        est_msg.pose.theta = self.x[2]
        self.pub_est.publish(est_msg)


if __name__ == '__main__':
    rospy.init_node('state_estimator', anonymous=True)
    est = Estimator()
    rospy.spin()
